
# Prafull AI Agent - Android Tablet

## Where to put API Key
1. Build and install APK (see below)
2. Open App -> Settings (top right)
3. Base URL: https://api.openai.com/v1  (or your compatible provider like OpenRouter, Groq with OpenAI compat)
4. API Key: paste your key - stored in EncryptedSharedPreferences, never hardcoded
5. Model: gpt-4o-mini or gpt-4o or llama3-70b (depending on provider)
6. Save

Permissions: grant Mic, Contacts, Call, SMS when prompted. Also enable Accessibility + Notification if you want automation.

## Build APK
1. Open Android Studio Hedgehog+
2. Open folder PrafullAIAgent
3. Let Gradle sync
4. Connect tablet via USB, enable Developer Options > USB Debugging
5. Run > Run 'app' -> selects tablet
OR Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk -> adb install or copy to tablet

Min SDK 26 (Android 8). Tested for Tablet landscape.

## Features Implemented Real
- SpeechRecognizer with hi-IN + en-IN
- TTS Hindi/English auto-switch
- LLM JSON parsing for intents
- Open app via packageManager
- Search Google/YouTube via Intent
- Open settings pages via Settings intents
- Call/SMS with confirmation dialog + runtime permission
- AccessibilityService stub ready
- NotificationListener stub ready
- Secure storage

## Limitations (Android restricts)
- Cannot bypass PIN/biometric/banking app protections - enforced
- SMS direct send requires user confirmation UI - we use ACTION_SENDTO
- Adjusting secure settings needs system app - we show limitation
