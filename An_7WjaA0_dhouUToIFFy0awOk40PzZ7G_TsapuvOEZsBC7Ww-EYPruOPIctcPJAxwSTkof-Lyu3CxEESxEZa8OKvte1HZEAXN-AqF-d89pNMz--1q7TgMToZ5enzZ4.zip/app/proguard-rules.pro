
-keep class com.prafull.aiagent.** { *; }
