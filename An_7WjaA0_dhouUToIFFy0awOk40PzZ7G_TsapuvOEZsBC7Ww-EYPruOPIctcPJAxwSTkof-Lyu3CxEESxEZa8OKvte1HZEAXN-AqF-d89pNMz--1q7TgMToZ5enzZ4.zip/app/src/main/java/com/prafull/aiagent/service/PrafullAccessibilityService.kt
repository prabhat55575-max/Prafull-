
package com.prafull.aiagent.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class PrafullAccessibilityService : AccessibilityService() {
    companion object {
        var instance: PrafullAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun performGlobalActionSafe(action: Int): Boolean {
        return performGlobalAction(action)
    }
}
