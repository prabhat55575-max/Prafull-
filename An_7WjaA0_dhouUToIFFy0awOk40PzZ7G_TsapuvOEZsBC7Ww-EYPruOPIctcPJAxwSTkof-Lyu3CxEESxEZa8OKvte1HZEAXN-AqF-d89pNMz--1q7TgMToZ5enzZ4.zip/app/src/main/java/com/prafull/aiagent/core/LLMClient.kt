
package com.prafull.aiagent.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class LLMClient(private val securePrefs: SecurePrefs) {

    private val client = OkHttpClient()

    private val systemPrompt = """
You are Prafull AI Agent, an Android tablet assistant. Understand Hindi, English, Hinglish.
You must output ONLY valid JSON with this schema:
{
  "thought": "short reasoning in English",
  "reply_hinglish": "User-facing reply in user's language (Hindi/English mix as user used)",
  "action": {
    "type": "open_app | open_settings | search_google | search_youtube | open_website | make_call | send_sms | adjust_volume | none",
    "app_name": "youtube, chrome, whatsapp etc (if open_app)",
    "query": "search query or website url or phone number or contact name",
    "message": "for SMS body",
    "requires_confirmation": true/false
  }
}

Rules:
- App names mapping: youtube->com.google.android.youtube, chrome->com.android.chrome, whatsapp->com.whatsapp, instagram->com.instagram.android, gmail->com.google.android.gm, maps->com.google.android.apps.maps, phone->com.google.android.dialer, settings->android.settings
- If user says "YouTube खोलो" -> open_app youtube
- If "Chrome खोलकर AI search करो" -> search_google
- If sensitive action (call, sms, delete) -> requires_confirmation=true
- Never output anything except JSON.
- Support Hindi: "राहुल को कॉल करो" -> make_call with query "राहुल"
""".trimIndent()

    suspend fun understandCommand(userText: String): JSONObject = withContext(Dispatchers.IO) {
        val apiKey = securePrefs.getApiKey()
        if (apiKey.isBlank()) throw Exception("API Key not set. Please go to Settings.")

        val baseUrl = securePrefs.getBaseUrl().trimEnd('/')
        val model = securePrefs.getModel()

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        messages.put(JSONObject().put("role", "user").put("content", userText))

        val bodyJson = JSONObject()
        bodyJson.put("model", model)
        bodyJson.put("messages", messages)
        bodyJson.put("temperature", 0.3)
        bodyJson.put("response_format", JSONObject().put("type", "json_object"))

        val request = Request.Builder()
            .url("$baseUrl/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            throw Exception("LLM API Error ${'$'}{response.code}: ${'$'}{response.body?.string()}")
        }
        val respStr = response.body?.string() ?: throw Exception("Empty response")
        val json = JSONObject(respStr)
        val content = json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        return@withContext JSONObject(content)
    }
}
