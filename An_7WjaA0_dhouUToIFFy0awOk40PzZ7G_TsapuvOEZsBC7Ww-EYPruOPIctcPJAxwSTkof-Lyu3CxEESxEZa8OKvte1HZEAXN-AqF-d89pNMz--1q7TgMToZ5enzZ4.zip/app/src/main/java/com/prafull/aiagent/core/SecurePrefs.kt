
package com.prafull.aiagent.core

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePrefs(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "prafull_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(key: String) = prefs.edit().putString("api_key", key).apply()
    fun getApiKey(): String = prefs.getString("api_key", "") ?: ""
    fun saveBaseUrl(url: String) = prefs.edit().putString("base_url", url).apply()
    fun getBaseUrl(): String = prefs.getString("base_url", "https://api.openai.com/v1") ?: "https://api.openai.com/v1"
    fun saveModel(model: String) = prefs.edit().putString("model", model).apply()
    fun getModel(): String = prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
}
