
package com.prafull.aiagent.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class PrafullNotificationService : NotificationListenerService() {
    companion object {
        var lastNotifications: List<StatusBarNotification> = emptyList()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        lastNotifications = activeNotifications?.toList() ?: emptyList()
    }
}
