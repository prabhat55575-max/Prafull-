
package com.prafull.aiagent.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import org.json.JSONObject

class ActionExecutor(private val context: Context) {

    private val appMap = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "map" to "com.google.android.apps.maps",
        "phone" to "com.google.android.dialer",
        "dialer" to "com.google.android.dialer",
        "settings" to "com.android.settings",
        "camera" to "com.android.camera2",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos"
    )

    fun execute(actionJson: JSONObject): String {
        val type = actionJson.optString("type", "none")
        val appName = actionJson.optString("app_name", "").lowercase()
        val query = actionJson.optString("query", "")
        val message = actionJson.optString("message", "")

        return try {
            when (type) {
                "open_app" -> openApp(appName)
                "open_settings" -> openSettingsPage(query)
                "search_google" -> searchGoogle(query)
                "search_youtube" -> searchYoutube(query)
                "open_website" -> openWebsite(query)
                "make_call" -> "CALL:${'$'}query" // handled in UI with permission check
                "send_sms" -> "SMS:${'$'}query|${'$'}message"
                "adjust_volume" -> adjustVolume(query)
                else -> "No action taken."
            }
        } catch (e: Exception) {
            "Failed: ${'$'}{e.message}"
        }
    }

    private fun openApp(name: String): String {
        val pkg = appMap[name] ?: name
        val pm = context.packageManager
        val launch = pm.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
            return "Opened ${'$'}name"
        }
        // Try to find by query all packages
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
            val apps = pm.queryIntentActivities(intent, 0)
            val found = apps.find { it.activityInfo.packageName.contains(name, true) || it.loadLabel(pm).toString().contains(name, true) }
            if (found != null) {
                val i = pm.getLaunchIntentForPackage(found.activityInfo.packageName)
                i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return "Opened ${'$'}{found.loadLabel(pm)}"
            }
        } catch (_: Exception) {}
        return "App '$name' not installed."
    }

    private fun openSettingsPage(page: String): String {
        val intent = when(page.lowercase()) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Opened settings: ${'$'}page"
    }

    private fun searchGoogle(query: String): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${'$'}{Uri.encode(query)}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Searching Google for $query"
    }

    private fun searchYoutube(query: String): String {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${'$'}{Uri.encode(query)}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Searching YouTube for $query"
    }

    private fun openWebsite(url: String): String {
        var finalUrl = url
        if (!finalUrl.startsWith("http")) finalUrl = "https://$finalUrl"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(finalUrl))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Opening $finalUrl"
    }

    private fun adjustVolume(level: String): String {
        Toast.makeText(context, "Please use volume buttons - direct volume control requires extra permission on Android 8+", Toast.LENGTH_LONG).show()
        return "Volume adjustment requires manual control on this Android version."
    }
}
