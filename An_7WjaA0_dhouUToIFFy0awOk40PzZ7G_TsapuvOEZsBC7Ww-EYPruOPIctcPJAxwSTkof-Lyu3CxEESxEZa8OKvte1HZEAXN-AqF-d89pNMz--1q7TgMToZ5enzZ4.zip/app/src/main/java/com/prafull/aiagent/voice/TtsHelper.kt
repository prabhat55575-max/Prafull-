
package com.prafull.aiagent.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TtsHelper(context: Context) {
    private var tts: TextToSpeech? = null
    var isReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isReady = true
                // Try Hindi first, fallback to English
                val hi = tts?.setLanguage(Locale("hi", "IN"))
                if (hi == TextToSpeech.LANG_MISSING_DATA || hi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
            }
        }
    }

    fun speak(text: String) {
        if (!isReady) return
        // Auto detect Hindi characters to switch voice
        val hasHindi = text.any { it.code in 0x0900..0x097F }
        if (hasHindi) {
            tts?.language = Locale("hi", "IN")
        } else {
            tts?.language = Locale("en", "IN")
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "prafull-utterance")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
