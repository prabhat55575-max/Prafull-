
package com.prafull.aiagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.prafull.aiagent.actions.ActionExecutor
import com.prafull.aiagent.core.LLMClient
import com.prafull.aiagent.core.SecurePrefs
import com.prafull.aiagent.ui.PrafullTheme
import com.prafull.aiagent.voice.SpeechHelper
import com.prafull.aiagent.voice.TtsHelper
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private lateinit var speechHelper: SpeechHelper
    private lateinit var ttsHelper: TtsHelper
    private lateinit var securePrefs: SecurePrefs
    private lateinit var llmClient: LLMClient
    private lateinit var actionExecutor: ActionExecutor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        securePrefs = SecurePrefs(this)
        llmClient = LLMClient(securePrefs)
        actionExecutor = ActionExecutor(this)
        ttsHelper = TtsHelper(this)
        speechHelper = SpeechHelper(this)

        setContent {
            var darkMode by remember { mutableStateOf(true) }
            PrafullTheme(dark = darkMode) {
                MainScreen()
            }
        }
    }

    @Composable
    fun MainScreen() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var transcript by remember { mutableStateOf("") }
        var partialTranscript by remember { mutableStateOf("") }
        var aiResponse by remember { mutableStateOf("नमस्ते! मैं Prafull AI हूँ। बोलिए, क्या करना है?") }
        var status by remember { mutableStateOf("Idle") }
        var isListening by remember { mutableStateOf(false) }
        var textInput by remember { mutableStateOf("") }
        var showSettings by remember { mutableStateOf(false) }
        var pendingAction by remember { mutableStateOf<JSONObject?>(null) }

        val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { perms ->
            if (perms[Manifest.permission.RECORD_AUDIO] == false) {
                Toast.makeText(context, "Mic permission required", Toast.LENGTH_SHORT).show()
            }
        }

        LaunchedEffect(Unit) {
            val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS)
            val toRequest = perms.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
            if (toRequest.isNotEmpty()) permissionLauncher.launch(toRequest.toTypedArray())
        }

        speechHelper.onPartial = { partialTranscript = it }
        speechHelper.onResult = { result ->
            transcript = result
            partialTranscript = ""
            isListening = false
            status = "Understanding..."
            scope.launch {
                try {
                    val parsed = llmClient.understandCommand(result)
                    val reply = parsed.optString("reply_hinglish", "Ho gaya!")
                    val action = parsed.optJSONObject("action")
                    aiResponse = reply
                    ttsHelper.speak(reply)

                    if (action != null) {
                        val needsConfirm = action.optBoolean("requires_confirmation", false)
                        if (needsConfirm) {
                            pendingAction = action
                            status = "Confirmation required: ${'$'}{action.optString("type")}"
                        } else {
                            val res = actionExecutor.execute(action)
                            status = res
                            handleSensitiveReturn(res, action)
                        }
                    } else {
                        status = "No action"
                    }
                } catch (e: Exception) {
                    aiResponse = "Error: ${'$'}{e.message}"
                    status = "Error"
                }
            }
        }
        speechHelper.onError = {
            isListening = false
            status = "Listen error: $it"
        }

        fun processTextInput(input: String) {
            if (input.isBlank()) return
            transcript = input
            status = "Understanding..."
            scope.launch {
                try {
                    val parsed = llmClient.understandCommand(input)
                    val reply = parsed.optString("reply_hinglish", "Ho gaya!")
                    val action = parsed.optJSONObject("action")
                    aiResponse = reply
                    ttsHelper.speak(reply)
                    if (action != null) {
                        val needsConfirm = action.optBoolean("requires_confirmation", false)
                        if (needsConfirm) {
                            pendingAction = action
                            status = "Confirm: ${'$'}{action.optString("type")} - ${'$'}{action.optString("query")}"
                        } else {
                            status = actionExecutor.execute(action)
                        }
                    }
                } catch (e: Exception) {
                    aiResponse = "Error: ${'$'}{e.message}"
                }
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(title = { Text("Prafull AI Agent", fontWeight = FontWeight.Bold) },
                    actions = {
                        TextButton(onClick = { showSettings = true }) { Text("Settings") }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Status
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Status: ${'$'}status", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text("Transcript:", fontWeight = FontWeight.Bold)
                        Text(if (partialTranscript.isNotEmpty()) partialTranscript else transcript)
                        Spacer(Modifier.height(8.dp))
                        Text("AI:", fontWeight = FontWeight.Bold)
                        Text(aiResponse, fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(24.dp))

                // Mic Button
                Button(
                    onClick = {
                        if (isListening) {
                            speechHelper.stop()
                            isListening = false
                            status = "Stopped"
                        } else {
                            partialTranscript = ""
                            isListening = true
                            status = "Listening... Hindi/English"
                            speechHelper.startListening()
                        }
                    },
                    modifier = Modifier.size(140.dp),
                    shape = androidx.compose.foundation.shape.CircleShape
                ) {
                    Text(if (isListening) "Stop" else "Mic", fontSize = 20.sp)
                }

                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    label = { Text("Type command: YouTube खोलो") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { processTextInput(textInput) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Send")
                }

                if (pendingAction != null) {
                    Spacer(Modifier.height(16.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Confirmation Required", fontWeight = FontWeight.Bold)
                            Text(pendingAction.toString())
                            Row {
                                Button(onClick = {
                                    val res = actionExecutor.execute(pendingAction!!)
                                    status = res
                                    handleSensitiveReturn(res, pendingAction!!)
                                    pendingAction = null
                                }) { Text("Confirm") }
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = { pendingAction = null; status = "Cancelled" }) { Text("Cancel") }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Text("Examples: 'YouTube खोलो', 'Chrome खोलकर Google पर AI search करो', 'WhatsApp खोलो', 'WiFi settings खोलो'", fontSize = 12.sp)
            }
        }

        if (showSettings) {
            SettingsDialog(onDismiss = { showSettings = false })
        }
    }

    private fun handleSensitiveReturn(res: String, action: JSONObject) {
        if (res.startsWith("CALL:")) {
            val numberOrName = res.removePrefix("CALL:")
            // If it's a name, need to resolve contacts - simplified
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${'$'}numberOrName"))
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    startActivity(intent)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Call failed: ${'$'}{e.message}", Toast.LENGTH_LONG).show()
            }
        } else if (res.startsWith("SMS:")) {
            val parts = res.removePrefix("SMS:").split("|")
            val to = parts.getOrNull(0) ?: ""
            val body = parts.getOrNull(1) ?: ""
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${'$'}to")).apply { putExtra("sms_body", body) }
            startActivity(intent)
        }
    }

    @Composable
    fun SettingsDialog(onDismiss: () -> Unit) {
        var apiKey by remember { mutableStateOf(securePrefs.getApiKey()) }
        var baseUrl by remember { mutableStateOf(securePrefs.getBaseUrl()) }
        var model by remember { mutableStateOf(securePrefs.getModel()) }
        val context = LocalContext.current

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Settings") },
            text = {
                Column {
                    OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key (stored encrypted)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Enable Accessibility Service") }
                    Spacer(Modifier.height(4.dp))
                    Button(onClick = {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Enable Notification Access") }
                }
            },
            confirmButton = {
                Button(onClick = {
                    securePrefs.saveApiKey(apiKey)
                    securePrefs.saveBaseUrl(baseUrl)
                    securePrefs.saveModel(model)
                    Toast.makeText(context, "Saved securely", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        )
    }

    override fun onDestroy() {
        speechHelper.stop()
        ttsHelper.shutdown()
        super.onDestroy()
    }
}
